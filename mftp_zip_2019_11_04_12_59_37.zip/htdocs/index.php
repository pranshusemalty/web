<?php
session_start();
 if(isset($_SESSION['username']) && !empty($_SESSION['username'])) 
 {
    $user=$_SESSION['username'];
    $ses=' Logout';
    $link='php/logout.php';
    $v=1;
}
else
{
    $ses=' Login';
    $link='php/login.html';
    $v=0;
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<!--online cdn-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!--scripts-->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!--scripts-->
 
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" type="text/css" href="css/home.css">
	<!--online cdn-->

</head>
<body>
<!--navbar-->
     <div class="container-fluid" style="padding:0%;height:40%;">
       
  <nav class="navbar fixed-top  navbar-expand-lg navbar-dark bg-dark"  >
  <a class="navbar-brand" href="../index.php" style="padding-left:10%;">Trends</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav " style="padding-left: 70%;">
      <li class="nav-item active">
        <a class="nav-link" href="">Book</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="#">Policy</a>
      </li>
      <li class="nav-item dropdown active">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Account
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="<?php echo$link;?>"><?php echo$ses;?></a>
          <a class="dropdown-item" href="php/oderdisp.php"><?php if($v==1){echo"Order History";}?></a>
          <a class="dropdown-item" href="#">Details</a>
           
        </div>
      </li>
    </ul>
   
</nav>
 <!---->

<!--carousal-->
  
<div class="bd-example">
  <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
      <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="images/4.jpg" class="d-block w-100" alt="...">
        <div class="carousel-caption d-none d-md-block">
          <h5>Rent a bike</h5>
          <p>Because chill rides are necessary.</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="images/5.jpg" class="d-block w-100" alt="...">
        <div class="carousel-caption d-none d-md-block">
          <h5>Second slide label</h5>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="images/7dd.jpg" class="d-block w-100" alt="...">
        <div class="carousel-caption d-none d-md-block">
          <h5>Third slide label</h5>
          <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
        </div>
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>

<!--carousal-->
 
 

<div class="container-fluid" style="padding: 0%;">
<!--box1-->
 
	<div class="box1">
		<br><br><br>
	<!--container-->
	<div class="container-fluid">
 	<div class="row  ">
 		<!--col1-->
 		<div class="col-lg-4 col-md-4 col-sm-4 col-4 align-self-start"  >
 			<div class="card"  >
  <img src="images/8.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <a href="php/client.php">
   <button class="btn btn-primary btn-sm">Rent</button></a>
    
  </div>
</div>
 			
 		</div>
 		<!--col1-->
 		<!--col2-->
 		<div class="col-lg-4 col-md-4 col-sm-4 col-4 align-self-start"  >
 			<div class="card"  >
  <img src="images/2.jpg" class="card-img-top" alt="...">
  <div class="card-body">
     <button class="btn btn-primary btn-sm">Travel</button>
  </div>
</div>
 			
 		</div>
 		<!--col2-->
 		<!--col3-->
 		<div class="col-lg-4 col-md-4 col-sm-4 col-4 align-self-start">
 			<div class="card"  >
  <img src="images/9.jpg" class="card-img-top" alt="...">
  <div class="card-body">
  <button class="btn btn-primary btn-sm">Buy/Sell</button>
  </div>
</div>
 			
 		</div>
 		<!--col3-->

 	</div>
 	</div>
	<!--container-->
 	<br><br>
 			 <!--jumbotron
 		 <div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h1 class="display-4">We provide valueable service</h1>
    <img src="images/11.jpg" style="width:100%;">
    <p class="lead">This is a modified jumbotron that occupies the entire horizontal space of its parent.</p>
  </div>
</div>
-->

	
</div>
<!--box1-->
</div>



 
	 
		 

	 
 </div>
</body>
</html>