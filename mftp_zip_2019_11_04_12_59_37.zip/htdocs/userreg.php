 <?php

$con = mysqli_connect("sql100.byetcluster.com","epiz_24722732","KoFjb5kyKo7XRt","epiz_24722732_myride") or
die(mysqli_error($con));
error_reporting(0);

$email = $_GET['email'];
$password =$_GET['password'];
$city=$_GET['city'];
$state=$_GET['state'];
$zip=$_GET['zipcoad'];
$q= "select * from userdata where email='$email'";
$res = mysqli_query($con,$q) or
die(mysqli_error($con));
$num = mysqli_num_rows($res);

if($num>=1)
{
  echo"This email is already registered.Please login or use another email.";
  header('refresh:2; url=php/login.html');
}
else
{
    $ur = "insert into userdata(email,password,city,state,zip)
values ('$email','$password','$city','$state','$zip')";
echo"Congratulations!!!!!!!!!!!!!.Please Login";
 header('refresh:2; url=index.php');
  
}
$user_registration_submit = mysqli_query($con,$ur) or
die(mysqli_error($con));

?>

