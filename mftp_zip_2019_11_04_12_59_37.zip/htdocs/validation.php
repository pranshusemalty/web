


<?php
$con = mysqli_connect("sql100.byetcluster.com","epiz_24722732","KoFjb5kyKo7XRt","epiz_24722732_myride") or
die(mysqli_error($con));
error_reporting(0);


$email = $_GET['email'];
    $password =$_GET['password'];


$q= "select * from userdata where email='$email'&& password = '$password'";
$result = mysqli_query($con,$q) or
die(mysqli_error($con));
$num = mysqli_num_rows($result);


        
if($num == 1)
{  
    session_start();
{   
$_SESSION['username']=$email;
$user=$_SESSION['username'];


}
    
    
    
    
    header('location:index.php');
     
}
else 
 {      $message="Please,Signup before you login!";
        echo "<script type='text/javascript'>alert('$message');</script>";
        echo "You are being redirected.Please Signup";
         $email =0;
         $password =0;
        header('refresh:1; url=php/signup.html');
       
         
       
 }




 
?>
