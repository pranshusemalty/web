  <?php

 session_start(); 

 if(isset($_SESSION['username']) && !empty($_SESSION['username'])) 
 {
    $user=$_SESSION['username'];
    $ses=' Logout';
    $link='logout.php';
}
else
{
    $ses=' Login';
    $link='login.html';
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>result</title>
	<!--online cdn-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!--scripts-->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!--scripts-->
<link href="https://fonts.googleapis.com/css?family=PT+Sans&display=swap" rel="stylesheet">
 
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" type="text/css" href="../css/home.css">
  <script src="https://kit.fontawesome.com/1f4b63a1b8.js" crossorigin="anonymous"></script>
	<!--online cdn-->
  <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
</head>
<body>
   

  <style >
    body
    {
      background-color: #E6F5F5;
    }
    .container
    {
      background-color: white;
    }
  </style>
<!--navbar-->
     <div class="container-fluid" style="padding:0%;height:40%;">
       
  <nav class="navbar fixed-top  navbar-expand-lg navbar-dark bg-dark"  >
  <a class="navbar-brand" href="../index.php" style="padding-left:10%;">Trends</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav " style="padding-left: 70%;">
      <li class="nav-item active">
        <a class="nav-link" href="">Book</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="#">Login</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="#">Policy</a>
      </li>
      <li class="nav-item dropdown active">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Account
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="<?php echo$link;?>"><?php echo$ses;?></a>
          <a class="dropdown-item" href="#">Order History</a>
          <a class="dropdown-item" href="#">Details</a>
           
        </div>
      </li>
    </ul>
   
</nav>
 <!---->
 <br>
 <br>
 <br>
 <br>
 <div>
  <div class="container" style="padding:3%;padding-top: 5%;">
    <div class="row">
      <div class="col-lg-2" style="font-size: 120%;">Starting Date:</div>
      <div class="col-lg-4">
        
         <input id="datepicker" required="" width="276" />
          <script>
        $('#datepicker').datepicker({
            uiLibrary: 'bootstrap4'
        });
    </script>
    
      </div>
      <div class="col-lg-2"  style="font-size: 120%;">
        Ending Date:
      </div>
      <div class="col-lg-4"  style="font-size: 120%;" onmouseover="f2();">

         <input id="datepicker1"  required="" width="276" />
         
          <script>
        $('#datepicker1').datepicker({
            uiLibrary: 'bootstrap4'
        });
    </script>
    <script type="text/javascript">
      
      function func()
      {
      var a=document.getElementById("datepicker").value;
      var b=document.getElementById("datepicker1").value;

      var d1= new Date(a);
      var d2= new Date(b);
      var c = d2.getTime()-d1.getTime();
      var days =c/(1000 * 3600 * 24);
      
      document.getElementById('d').setAttribute('value', days);



      }
      function f2()
      {
          var a=document.getElementById("datepicker").value;
      var b=document.getElementById("datepicker1").value;

      var d1= new Date(a);
      var d2= new Date(b);
      var c = d2.getTime()-d1.getTime();
      var days =c/(1000 * 3600 * 24);
       document.getElementById('d').setAttribute('value', days);
          
      }
      

    </script>
      </div>
     
      <!-- val -->
    </div>
    <div class="row">
       <div class="col-lg-12">
        <br>

      </div>
      
      <div class="col-lg-12">
        <form method="POST" action="interface.php">
        <input type="hidden" for="days" name="days" id="d" value="" >
        <button  type="submit" onclick="func();" onmouseover="func();" class="btn btn-primary">Search</button>
        </form>

      </div>
     
    </div>
  </div>
  </div>
</body>
</html>