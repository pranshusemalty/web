<?php
$con=mysqli_connect("sql100.byetcluster.com","epiz_24722732","KoFjb5kyKo7XRt","epiz_24722732_myride") or die(mysqli_error($con));
error_reporting(0);
$q="select * from bike";
$result=mysqli_query($con,$q) or die(mysql_error($con));
$num = mysqli_num_rows($result);

session_start();
{
$user=$_SESSION['username'];

}
 if(isset($_SESSION['username']) && !empty($_SESSION['username'])) 
 {
    $user=$_SESSION['username'];
    $ses=' Logout';
    $link='logout.php';
}
else
{
    $ses=' Login';
    $link='login.html';
}
$cname=$row["name"];
$type=$row["type"];
$price=$row["price"];
$s =$_POST['days'];

 




?>
<!DOCTYPE html>
<html>
<head>
  <title>result</title>
  <!--online cdn-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!--scripts-->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!--scripts-->
<link href="https://fonts.googleapis.com/css?family=PT+Sans&display=swap" rel="stylesheet">
 
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" type="text/css" href="../css/home.css">
  <script src="https://kit.fontawesome.com/1f4b63a1b8.js" crossorigin="anonymous"></script>
  <!--online cdn-->
  <script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
</head>
<body>
   

  <style >
    body
    {
      background-color: #E6F5F5;
    }
    .container
    {
      background-color: white;
    }
  </style>
    <!--navbar-->
     <div class="container-fluid" style="padding:0%;height:40%;">
       
  <nav class="navbar fixed-top  navbar-expand-lg navbar-dark bg-dark"  >
  <a class="navbar-brand" href="../index.php" style="padding-left:10%;">Trends</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav " style="padding-left: 70%;">
      <li class="nav-item active">
        <a class="nav-link" href="">Book</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="#">Login</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="#">Policy</a>
      </li>
      <li class="nav-item dropdown active">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Account
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="<?php echo$link;?>"><?php echo$ses;?></a>
          <a class="dropdown-item" href="#">Order History</a>
          <a class="dropdown-item" href="#">Details</a>
           
        </div>
      </li>
    </ul>
   
</nav>
 <!---->
 <br>
 <br>
 <br>
 <br>
 <div>
 
    
  
  <?php
   $message="Please choose a valid date or At least one Day";
  if($s==0||$s<0)
  {  echo "<script type='text/javascript'>alert('$message');</script>";
    header('refresh:0,url=date.php');
  }
  else
  {

 while($row = mysqli_fetch_array($result))
 {?><br>
  <div class="container border shadow p-3 mb-5 bg-white " >
    <!-- row1 -->
 <div class="row  border-bottom"   >

  <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6" style=" font-family: 'PT Sans', sans-serif;font-size:130%;">
      <?php $na=$row["name"]; echo$na;?>
   </div>
   <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"></div>
   <div class="col-lg-3 col-md-3 col-sm-3 col-xs-3"><i class="fas fa-car-side"></i>Fare Details</div>

 </div>
 <!-- row1 -->
  <!-- row2 -->
 <div class="row" style="padding-top:2%;">
  <div class="col-lg-3 col-md-12 col-sm-12 col-xs-12 ">
     <div class="img-thumbnail"><?php echo $img='<img src="data:image/jpeg;base64,'.base64_encode($row['img']).'" height="150" width="230"/>';
;?></div>
      
   </div>
   <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
    <!-- inside col -->
    <div class="row">
      <div class="col-lg-3 col-md-4 col-sm-5 col-3"><i class="fas fa-oil-can">&nbspType:</i></div>
      <div class="col-lg-6 col-md-6 col-sm-6 col-3"><?php echo$row["type"];?></div>
    </div>
    <br>
    <div class="row">
      <div class="col-lg-3 col-md-3 col-sm-2 col-3 ">&nbsp  Engine:</div>
      <div class="col-lg-6 col-md-6 col-sm-6 col-6"><?php echo$row["power"]."cc";?></div>
    </div>
    <!-- insider -->
   </div>

   <div class="col-lg-2 col-md-3 col-sm-2 col-2" >
    <div class="row">
      <div class="col-lg-5 col-md-2 col-sm-3 col-1">
     <i class="fas fa-tags">Price:</i>
     </div>
     <div class="col-lg-1 col-md-1 col-sm-1 col-0"></div>
    <div class="col-lg-4 col-md-2 col-sm-12 col-2">
      <?php echo$row["price"]."/Day";?>
   </div>
   
   <div class="col-lg-2 col-md-6 col-sm-12 col-12">
   
     <strong>Days:</strong><?php echo $s;?>
     </div></div>

   <div>

      
      
      

   </div>
   </div>

   
    <div class="col-lg-2 col-md-2 col-sm-12 col-12">
      <br><br>
       <div style="font-size:140%;"> Total Cost:
        <div style="color:red;"><?php $z =$row["price"]*$s; echo"₹".$z;?></div>
       <form method="POST" action="loader.php">
        <input type="hidden"  for="total" name="total" value='<?php echo"$z";?>'>
        <input type="hidden"  for="name" name="name" value='<?php echo"$na";?>'>
       <button type="submit" class="btn btn-secondary">Book</button>
       </form>
     </div>
   </div>
 </div>
</div>
 <!-- row2 -->
 </div>
<!--container end-->

  <?php
} 
}

 
?>

    
  </div>

 
  



</body>
</html>